from fastapi import APIRouter

from profiles import PROFILES

from database import (
    get_profile_scores
)

router = APIRouter()


@router.get("/profiles")
def profiles():

    return list(
        PROFILES.keys()
    )


@router.get("/profile-scores")
def profile_scores(
    profile="wrights_field"
):

    return get_profile_scores(
        profile
    )
