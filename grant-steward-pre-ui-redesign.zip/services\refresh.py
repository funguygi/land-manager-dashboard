from datetime import datetime

from scraper import (
    fetch_ca_grants,
    fetch_grant_text
)

from nfwf_scraper import (
    fetch_nfwf_grants
)

from grantsgov_scraper import (
    fetch_grantsgov_grants
)

from scorer import score_grant

from database import (
    save_grant,
    save_score
)

from metadata import (
    set_last_refresh
)

from profiles import (
    PROFILES
)


def refresh_grants():

    grants = (
        fetch_ca_grants()
        + fetch_nfwf_grants()
        + fetch_grantsgov_grants()
    )

    saved = 0

    for grant in grants:

        try:

            text = fetch_grant_text(
                grant["url"]
            )

            if not text:
                continue

            best_score = 0

            for profile in PROFILES:

                result = score_grant(
                    text,
                    profile=profile
                )

                score = result["score"]

                save_score(
                    grant["url"],
                    profile,
                    score
                )

                best_score = max(
                    best_score,
                    score
                )

            grant["score"] = best_score

            save_grant(grant)

            saved += 1

        except Exception as e:

            print(
                "Refresh error:",
                grant.get("title"),
                e
            )

    set_last_refresh(
        datetime.now().strftime(
            "%Y-%m-%d %H:%M"
        )
    )

    return {
        "processed": len(grants),
        "saved": saved
    }
