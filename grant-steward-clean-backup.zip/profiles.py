PROFILES = {

    "wrights_field": {

        "name": "Wright's Field",

        "high_match": {

            # core conservation
            "conservation": 30,
            "habitat": 25,
            "restoration": 25,
            "enhancement": 20,
            "stewardship": 25,

            # preserve management
            "reserve": 25,
            "reserve lands": 30,
            "management": 15,
            "monitoring": 15,

            # habitats
            "wildlife": 25,
            "riparian": 25,
            "grassland": 25,
            "oak woodland": 25,
            "chaparral": 25,
            "vernal pool": 25,

            # ecology
            "biodiversity": 20,
            "watershed": 20,
            "ecosystem": 20,
            "ecological": 20,

            # land trust relevance
            "open space": 20,
            "nonprofit": 20,
            "land acquisition": 30,
            "land management": 25,

            # California relevance
            "california": 10,

            # climate & resilience
            "wildfire": 15,
            "landscape resilience": 15,
            "revegetation": 20,

            # NCCP-specific
            "nccp": 40,
            "natural community conservation": 40
        },

        "low_match": {
            "archery": -100,
            "tobacco": -100,
            "library": -80,
            "digital literacy": -80,
            "sports": -100,
            "healthcare": -80,
            "graduate student": -100
        }
    },

    "research": {

        "name": "Research",

        "high_match": {

            "ecology": 40,
            "mycology": 40,
            "fungal": 35,
            "metagenomics": 35,
            "soil microbiome": 35,
            "environmental dna": 35,
            "edna": 35,
            "fungi": 35,
            "forest ecology": 30,
            "microbiome": 30,
            "ecosystem": 25,
            "bioinformatics": 25,
            "environmental genomics": 35,
            "microbial ecology": 35,
            "community ecology": 25,
            "population genetics": 25,
            "microbial": 30,
            "bioremediation": 30,
            "restoration ecology": 30,
            "landscape ecology": 30,
            "biodiversity": 25,
            "genomics": 25,
            "soil ecology": 25,
            "conservation biology": 25,
            "graduate student": 20,
            "research": 15
        },

        "low_match": {
            "archery": -100,
            "tobacco": -100,
            "sports": -100
        }
    },

    "mycology": {

        "name": "Mycology",

        "high_match": {

            "mycology": 40,
            "fungal": 40,
            "fungi": 40,
            "soil microbiome": 35,
            "microbiome": 30,
            "microbial ecology": 30,
            "decomposition": 25,
            "forest ecology": 25,
            "biodiversity": 20,
            "ecology": 20
        },

        "low_match": {}
    },

    "restoration": {

        "name": "Restoration Ecology",

        "high_match": {

            "restoration": 40,
            "revegetation": 35,
            "habitat": 30,
            "riparian": 30,
            "watershed": 30,
            "grassland": 25,
            "native vegetation": 25,
            "ecological": 20,
            "biodiversity": 20,
            "wildlife habitat": 20
        },

        "low_match": {}
    },
    "metagenomics": {

        "name": "Metagenomics",

        "high_match": {

            "metagenomics": 40,
            "genomics": 35,
            "sequencing": 35,
            "microbial": 30,
            "microbiome": 30,
            "bioinformatics": 25,
            "genetic": 20,
            "dna": 20,
            "rna": 20
        },

        "low_match": {}
    }
}