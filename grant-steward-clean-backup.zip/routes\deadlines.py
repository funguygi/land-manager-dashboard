from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from database import get_active_grants
from alerts import deadline_alert
from utils.templates import page_template

router = APIRouter()

from services.deadlines import (
    days_until_deadline,
    deadline_sort_key
)

@router.get("/deadlines", response_class=HTMLResponse)
def deadlines():

    grants = get_active_grants()

    grants.sort(
        key=lambda g: deadline_sort_key(g[6])
    )

    body = """
    <h1>Upcoming Deadlines</h1>

    <div class="card">

    <table>

    <tr>
        <th>Risk</th>
        <th>Status</th>
        <th>Countdown</th>
        <th>Deadline</th>
        <th>Title</th>
    </tr>
    """

    for g in grants:

        risk = deadline_alert(g[6])

        countdown = days_until_deadline(g[6])

        body += f"""
        <tr>

            <td>{risk}</td>

            <td>{g[11]}</td>

            <td>{countdown}</td>

            <td>{g[6]}</td>

            <td>
                <a href="/grant?url={g[0]}">
                    {g[1]}
                </a>
            </td>

        </tr>
        """

    body += """
    </table>

    </div>
    """

    return HTMLResponse(
        page_template(
            "Deadlines",
            body
        )
    )