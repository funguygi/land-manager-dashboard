import re

def extract_grant_info(text):

    info = {
        "agency": "",
        "status": "",
        "open_date": "",
        "funding": ""
    }

    agency = re.search(r"Grantor:\s*(.*?)\s*Portal ID:", text)

    if agency:
        info["agency"] = agency.group(1).strip()

    status = re.search(r"Status:\s*(.*?)\s*Open Date:", text)

    if status:
        info["status"] = status.group(1).strip()

    open_date = re.search(r"Open Date:\s*(.*?)\s*Opportunity Type:", text)

    if open_date:
        info["open_date"] = open_date.group(1).strip()

    info["funding"] = extract_funding(text)

    return info

def extract_deadline(text):

    patterns = [

        r"Application deadline.*?(\d{1,2}/\d{1,2}/\d{2,4}\s+\d{1,2}:\d{2})",

        r"closes at.*?(\d{1,2}:\d{2}.*?\w+\s+\w+\s+\d{1,2}(?:st|nd|rd|th)?,?\s+\d{4})",

        r"due by.*?(\d{1,2}/\d{1,2}/\d{2,4})",

        r"applications due.*?(\d{1,2}/\d{1,2}/\d{2,4})"
    ]

    for pattern in patterns:

        match = re.search(
            pattern,
            text,
            flags=re.IGNORECASE | re.DOTALL
        )

        if match:
            return match.group(1).strip()

    return ""

def extract_funding(text):

    match = re.search(
        r"Total estimated available funding.*?\$([\d,]+)",
        text,
        flags=re.IGNORECASE | re.DOTALL
    )

    if match:
        return "$" + match.group(1)

    return ""

def extract_categories(text):

    categories = []

    category_keywords = {

        "Wildlife": [
            "wildlife",
            "species",
            "habitat"
        ],

        "Restoration": [
            "restoration",
            "revegetation",
            "enhancement"
        ],

        "Watershed": [
            "watershed",
            "water quality",
            "riparian"
        ],

        "Land Protection": [
            "land acquisition",
            "conservation easement",
            "reserve"
        ],

        "Wildfire": [
            "wildfire",
            "fuel reduction",
            "prescribed fire"
        ],

        "Education": [
            "education",
            "training",
            "outreach"
        ]
    }

    text_lower = text.lower()

    for category, keywords in category_keywords.items():

        if any(keyword in text_lower for keyword in keywords):
            categories.append(category)

    return categories