from fastapi import APIRouter
from fastapi.responses import HTMLResponse

from profiles import PROFILES
from database import get_profile_scores
from metadata import get_last_refresh

router = APIRouter()

def dashboard_page_template(content):
    return HTMLResponse(content)

@router.get("/dashboard", response_class=HTMLResponse)
def dashboard(profile="wrights_field"):

    grants = get_profile_scores(profile)

    last_refresh = get_last_refresh()

    profile_links = ""

    for profile_name in PROFILES:

        profile_links += f"""
        <a href="/dashboard?profile={profile_name}">
            {PROFILES[profile_name]["name"]}
        </a> |
        """

    body = f"""
    <h1>🌿 Grant Steward Dashboard</h1>

    <p><b>Last Refresh:</b> {last_refresh}</p>

    <p><b>Profile:</b> {profile}</p>

    <p>{profile_links}</p>

    <table border="1">

        <tr>
            <th>Score</th>
            <th>Title</th>
            <th>Agency</th>
            <th>Deadline</th>
        </tr>
    """

    for g in grants:

        body += f"""
        <tr>
            <td>{g[8]}</td>

            <td>
                <a href="/grant?url={g[0]}">
                    {g[1]}
                </a>
            </td>

            <td>{g[3]}</td>

            <td>{g[6]}</td>

        </tr>
        """

    body += "</table>"

    return HTMLResponse(body)