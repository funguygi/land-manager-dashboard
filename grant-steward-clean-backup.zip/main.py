from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.responses import RedirectResponse
from nfwf_scraper import fetch_nfwf_grants
from grantsgov_scraper import fetch_grantsgov_grants
from routes.dashboard import router as dashboard_router
from routes.metrics import router as metrics_router
from routes.pipeline import router as pipeline_router
from routes.deadlines import router as deadlines_router
from routes.grants import router as grants_router
from routes.urgent import router as urgent_router
from routes.top_opportunities import router as top_router
from routes.work_queue import (
    router as work_queue_router
)
from routes.tasks import (
    router as tasks_router
)
from routes.board_report import (
    router as board_report_router
)
from routes.pdf_report import (
    router as pdf_report_router
)
from routes.calendar import (
    router as calendar_router
)
from routes.analytics import (
    router as analytics_router
)
from profiles import PROFILES
from parser import (
    extract_grant_info,
    extract_deadline,
    extract_funding
)
from scorer import score_grant
from scraper import fetch_ca_grants, fetch_grant_text
from metadata import set_last_refresh
from metadata import get_last_refresh
from datetime import datetime
from scheduler import start_scheduler
from services.deadline_summary import (
    deadlines_within_days
)

def load_all_grants():

    return (
        fetch_ca_grants()
        + fetch_nfwf_grants()
        + fetch_grantsgov_grants()
    )

app = FastAPI()

app.include_router(dashboard_router)
app.include_router(metrics_router)
app.include_router(pipeline_router)
app.include_router(deadlines_router)
app.include_router(grants_router)
app.include_router(urgent_router)
app.include_router(top_router)
app.include_router(
    work_queue_router
)
app.include_router(tasks_router)
app.include_router(
    board_report_router
)
app.include_router(
    pdf_report_router
)
app.include_router(
    calendar_router
)
app.include_router(
    analytics_router
)


from utils.templates import page_template

from database import (
    initialize_database,
    save_grant,
    save_score,
    get_saved_grants,
    get_profile_scores,
)

initialize_database()

@app.get("/refresh")
def refresh():

    set_last_refresh(
        datetime.now().strftime(
            "%Y-%m-%d %H:%M"
        )
    )

    return {
        "success": True,
        "message": "Refresh completed"
    }

@app.on_event("startup")
def startup_event():

    start_scheduler(refresh)

@app.get("/", response_class=HTMLResponse)
def home():

    grants = get_saved_grants()

    urgent = len(
        deadlines_within_days(
            grants,
            30
        )
    )

    total = len(grants)

    high = sum(
        1 for g in grants
        if g[9] == "High"
    )

    pipeline = sum(
        1 for g in grants
        if g[11] in [
            "Interested",
            "Preparing",
            "Submitted"
        ]
    )

    body = f"""
    <h1>🌿 Grant Steward</h1>

    <div class="stats">

        <div class="stat-card">
            <div class="stat-number">{total}</div>
            <div class="stat-label">Total Grants</div>
        </div>

        <div class="stat-card">
            <div class="stat-number">{high}</div>
            <div class="stat-label">High Priority</div>
        </div>

        <div class="stat-card">
            <div class="stat-number">{urgent}</div>
            <div class="stat-label">Urgent Deadlines</div>
        </div>

        <div class="stat-card">
            <div class="stat-number">{pipeline}</div>
            <div class="stat-label">Pipeline</div>
        </div>

    </div>

    <div class="card">

        <h2>System Status</h2>

        <p>
            <b>Last Refresh:</b>
            {get_last_refresh()}
        </p>

    </div>

    <div class="card">

        <h2>Quick Links</h2>

        <p>
            <a href="/top-opportunities">
                Top Opportunities
            </a>
        </p>

        <p>
            <a href="/urgent">
                Urgent Opportunities
            </a>
        </p>

        <p>
            <a href="/pipeline">
                Grant Pipeline
            </a>
        </p>

        <p>
            <a href="/metrics">
                Metrics
            </a>
        </p>

    </div>
    """

    return HTMLResponse(
        page_template(
            "Grant Steward",
            body
        )
    )

@app.get("/search")
def search(profile="wrights_field"):

    grants = load_all_grants()

    results = []

    for grant in grants[:15]:

        text = fetch_grant_text(grant["url"])

        if not text:
            continue

        score = score_grant(
            text,
            profile=profile
        )

        save_score(
            grant["url"],
            profile,
            score["score"]
        )

        results.append({
            "title": grant["title"],
            "url": grant["url"],
            "score": score["score"],
            "matches": score["matches"],
            "profile": profile
        })

    results.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    return results

@app.get("/saved")
def saved():

    return get_saved_grants()

@app.get("/profiles")
def profiles():

    from profiles import PROFILES

    return list(PROFILES.keys())

@app.get("/research")
def research_grants():

    grants = fetch_ca_grants()

    results = []

    for grant in grants[:15]:

        text = fetch_grant_text(grant["url"])

        if not text:
            continue

        score = score_grant(
            text,
            profile="research"
        )

        results.append({
            "title": grant["title"],
            "score": score["score"],
            "matches": score["matches"]
        })

    results.sort(
        key=lambda x: x["score"],
        reverse=True
    )

    return results[:20]

@app.get("/federal")
def federal():

    return search(
        profile="research"
    )

@app.get("/why")
def why(url: str, profile="wrights_field"):

    text = fetch_grant_text(url)

    result = score_grant(text, profile)

    return result

@app.get("/profile-scores")
def profile_scores(profile="wrights_field"):

    return get_profile_scores(profile)

@app.get("/research-dashboard")
def research_dashboard():

    return RedirectResponse(
        "/dashboard?profile=research",
        status_code=302
    )

@app.get("/health")
def health():

    ca = fetch_ca_grants()
    nfwf = fetch_nfwf_grants()
    grantsgov = fetch_grantsgov_grants()

    return {
        "california_grants": len(ca),
        "nfwf": len(nfwf),
        "grantsgov": len(grantsgov),

        "total_sources": 3,
        "total_opportunities":
            len(ca)
            + len(nfwf)
            + len(grantsgov)
    }
