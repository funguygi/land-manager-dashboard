ELIGIBILITY_RULES = {
    "501(c)(3)": 20,
    "nonprofit": 10,
    "land trust": 25,
    "conservation organization": 20,
    "wildlife": 10,
    "habitat": 10,
    "local government": -20,
    "tribal government only": -25,
}

def evaluate_eligibility(text):
    text = (text or "").lower()
    score = 0
    reasons = []

    for phrase, value in ELIGIBILITY_RULES.items():
        if phrase.lower() in text:
            score += value
            reasons.append(phrase)

    if score >= 30:
        status = "Likely Eligible"
    elif score >= 10:
        status = "Possibly Eligible"
    else:
        status = "Needs Review"

    return {
        "status": status,
        "score": score,
        "reasons": reasons
    }
