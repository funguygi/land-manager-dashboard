from profiles import PROFILES


def score_grant(text, profile="wrights_field"):

    text = text.lower()

    config = PROFILES[profile]

    score = 0
    reasons = []

    for keyword, points in config["high_match"].items():

        if keyword in text:

            score += points
            reasons.append(keyword)

    for keyword, penalty in config["low_match"].items():

        if keyword in text:

            score += penalty

    score = max(0, min(score, 100))

    return {
        "score": score,
        "matches": reasons,
        "profile": profile
    }